/**
 * Stability AI Module
 * Handles image generation via Stability AI API
 */

import { config } from '../../config.js';

export class Stability {
  constructor() {
    this.apiKey = config.api.stability;
    this.baseUrl = 'https://api.stability.ai/v1/generation/stable-diffusion-xl-1024-v1-0/text-to-image';
  }

  /**
   * Generate image using Stability AI API
   */
  async generate(prompt, seed, width = 1024, height = 1024) {
    try {
      if (!prompt) throw new Error('Prompt is empty');

      const payload = {
        text_prompts: [{ text: prompt, weight: 1 }],
        cfg_scale: 7,
        height: height,
        width: width,
        steps: 30,
        seed: seed
      };

      const response = await fetch(this.baseUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error(`Stability API error: ${response.status}`);
      }

      const data = await response.json();

      if (data.artifacts && data.artifacts.length > 0) {
        return {
          provider: 'Stability AI',
          url: `data:image/png;base64,${data.artifacts[0].base64}`
        };
      }

      throw new Error('No images returned from Stability AI');

    } catch (err) {
      console.error('Stability generation error:', err);
      return null;
    }
  }
}