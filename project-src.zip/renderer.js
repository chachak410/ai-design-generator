/**
 * Image Renderer Module
 * Handles rendering and feedback UI for generated images
 */

import { UI } from '../../utils/ui.js';
import { Helpers } from '../../utils/helpers.js';

export class Renderer {
  /**
   * Render generated images with feedback buttons
   */
  renderImages(images) {
    const pair = document.getElementById('image-pair');
    const feedbackButtons = document.getElementById('feedback-buttons');
    const container = document.getElementById('generated-images');

    if (!pair || !feedbackButtons || !container) {
      console.error('Required DOM elements not found');
      return;
    }

    // Clear previous content
    pair.innerHTML = '';
    feedbackButtons.innerHTML = '';
    container.classList.add('hidden');

    // Render images
    images.forEach((item, i) => {
      const div = document.createElement('div');
      const img = document.createElement('img');
      
      img.src = item.url;
      img.alt = `Generated image ${i + 1}`;
      img.onload = () => img.classList.add('loaded');

      const label = document.createElement('div');
      label.className = 'provider-label';
      label.textContent = item.provider;

      div.appendChild(img);
      div.appendChild(label);
      pair.appendChild(div);
    });

    // Create feedback buttons
    feedbackButtons.innerHTML = `
      <button class="btn btn-like-this" data-i18n-button="btn-left-better" data-choice="0">
        Left is better
      </button>
      <button class="btn btn-like-that" data-i18n-button="btn-right-better" data-choice="1">
        Right is better
      </button>
      <button class="btn btn-tie" data-i18n-button="btn-tie" data-choice="tie">
        It's a tie
      </button>
      <button class="btn btn-both-bad" data-i18n-button="btn-both-bad" data-choice="both-bad">
        Both bad
      </button>
    `;

    // Setup feedback button event listeners
    this.setupFeedbackButtons(images);

    // Show container with animation
    requestAnimationFrame(() => {
      if (window.i18n && window.i18n.renderAll) {
        window.i18n.renderAll();
      }
      container.classList.remove('hidden');
      container.scrollIntoView({ behavior: 'smooth' });
    });
  }

  /**
   * Setup event listeners for feedback buttons
   */
  setupFeedbackButtons(images) {
    const buttons = document.querySelectorAll('#feedback-buttons button');
    
    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        const choice = btn.dataset.choice;
        this.handleFeedback(choice, images);
      });
    });
  }

  /**
   * Handle user feedback
   */
  handleFeedback(choice, images) {
    if (choice === 'both-bad') {
      // Regenerate - handled by main generator
      console.log('User chose: both bad - triggering regeneration');
      UI.showMessage('template-status', 'Regenerating images...', 'info');
      // The generate button will handle this
      return;
    }

    if (choice === '0') {
      // Download left image
      Helpers.downloadImage(images[0].url, 'design-left.png');
      UI.showMessage('template-status', 'Left image downloaded!', 'success');
    } else if (choice === '1') {
      // Download right image
      Helpers.downloadImage(images[1].url, 'design-right.png');
      UI.showMessage('template-status', 'Right image downloaded!', 'success');
    } else if (choice === 'tie') {
      // Download both images
      Helpers.downloadImage(images[0].url, 'design-1.png');
      setTimeout(() => {
        Helpers.downloadImage(images[1].url, 'design-2.png');
      }, 500);
      UI.showMessage('template-status', 'Both images downloaded!', 'success');
    }

    console.log('User feedback:', choice);
  }
}