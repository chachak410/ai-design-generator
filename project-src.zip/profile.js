/**
 * Profile Management Module
 * Handles user profile viewing and editing
 */

import { UI } from '../../utils/ui.js';
import { Validation } from '../../utils/validation.js';
import { Sanitizer } from '../../utils/sanitizer.js';
import { FirebaseHelper } from '../../utils/firebase.js';

export class Profile {
  constructor(auth, db) {
    this.auth = auth;
    this.db = db;
  }

  /**
   * Load and display account information
   */
  async loadAccountInfo() {
    const currentUser = this.auth.getCurrentUser();
    
    if (!currentUser) {
      UI.showMessage('account-msg', 'Please sign in to view account information.', 'error');
      return;
    }

    try {
      const userData = await FirebaseHelper.getUserData(this.db, currentUser.uid);

      if (!userData) {
        UI.showMessage('account-msg', 'Account data not found.', 'error');
        return;
      }

      const userProductName = userData.productName || 'Not set';
      const userIndustryCode = userData.industryCode || '000000';
      const industryDisplay = userData.industryName || 'Not specified';

      const accountInfo = document.getElementById('account-info');
      if (accountInfo) {
        accountInfo.innerHTML = `
          <p><strong>Name:</strong> ${userData.name || 'Not set'}</p>
          <p><strong>Email:</strong> ${currentUser.email}</p>
          <p><strong>Industry:</strong> ${industryDisplay} (Code: ${userIndustryCode})</p>
          <p><strong>Template:</strong> ${userData.template || 'None'}</p>
          <p><strong>Product Name:</strong> ${userProductName}</p>
        `;
      }

      UI.checkProductWarning(userProductName);

    } catch (err) {
      UI.showMessage('account-msg', 'Error loading account: ' + err.message, 'error');
    }
  }

  /**
   * Show edit account form
   */
  async showEditForm() {
    const currentUser = this.auth.getCurrentUser();
    
    if (!currentUser) return;

    UI.hideElement('account-info');
    UI.hideElement('edit-account-btn');
    UI.showElement('account-form');

    try {
      const userData = await FirebaseHelper.getUserData(this.db, currentUser.uid);
      
      if (userData) {
        document.getElementById('account-name').value = userData.name || '';
        document.getElementById('account-product').value = userData.productName || '';
        document.getElementById('account-email').value = currentUser.email;
      }
    } catch (err) {
      UI.showMessage('account-msg', 'Error loading account data: ' + err.message, 'error');
    }
  }

  /**
   * Cancel edit and hide form
   */
  cancelEdit() {
    UI.hideElement('account-form');
    UI.showElement('edit-account-btn');
    UI.showElement('account-info');
    UI.hideMessage('account-msg');
  }

  /**
   * Update account information
   */
  async updateAccount(name, productName) {
    const currentUser = this.auth.getCurrentUser();
    
    if (!currentUser) {
      UI.showMessage('account-msg', 'Please sign in to update account.', 'error');
      return { success: false };
    }

    const sanitizedName = Sanitizer.sanitizeText(name);
    const sanitizedProductName = Sanitizer.sanitizeText(productName);

    // Validate inputs
    const validation = Validation.validateProfile(sanitizedName, sanitizedProductName);
    if (!validation.isValid) {
      UI.showMessage('account-msg', validation.errors.join(' '), 'error');
      return { success: false };
    }

    try {
      UI.showMessage('account-msg', 'Updating profile...', 'info');

      // Update Firestore
      await FirebaseHelper.updateUserData(this.db, currentUser.uid, {
        name: sanitizedName,
        productName: sanitizedProductName
      });

      // Update Firebase Auth display name
      await currentUser.updateProfile({ displayName: sanitizedName });

      // Update auth instance
      this.auth.setUserProductName(sanitizedProductName);

      UI.showMessage('account-msg', 'Profile updated successfully!', 'success');
      
      // Hide form and reload info
      this.cancelEdit();
      await this.loadAccountInfo();

      return { success: true };

    } catch (err) {
      UI.showMessage('account-msg', 'Error updating profile: ' + err.message, 'error');
      return { success: false, error: err.message };
    }
  }
}