/**
 * Registration Module
 * Handles user registration flow (3 steps)
 */

import { UI } from '../../utils/ui.js';
import { Validation } from '../../utils/validation.js';
import { Sanitizer } from '../../utils/sanitizer.js';
import { FirebaseHelper } from '../../utils/firebase.js';
import { Helpers } from '../../utils/helpers.js';
import { config } from '../../config.js';

export class Registration {
  constructor(auth, db) {
    this.auth = auth;
    this.db = db;
    this.tempEmail = null;
    this.tempIndustryCode = null;
    this.verificationCode = null;
  }

  /**
   * Step 1: Send verification code
   */
  async sendVerificationCode(email, industryCode) {
    const sanitizedEmail = Sanitizer.sanitizeEmail(email);
    const sanitizedCode = industryCode.trim().toUpperCase();

    // Validate inputs
    const validation = Validation.validateRegistrationStep1(sanitizedEmail, sanitizedCode);
    if (!validation.isValid) {
      UI.showMessage('register-msg-step1', validation.errors.join(' '), 'error');
      return { success: false };
    }

    try {
      // Check if industry code is valid
      const codeValidation = await FirebaseHelper.validateIndustryCode(this.db, sanitizedCode);
      
      if (!codeValidation.valid) {
        UI.showMessage('register-msg-step1', codeValidation.error, 'error');
        return { success: false };
      }

      // Generate and send verification code
      this.verificationCode = Helpers.generateVerificationCode();
      this.tempEmail = sanitizedEmail;
      this.tempIndustryCode = sanitizedCode;

      await emailjs.send(
        config.emailjs.serviceId,
        config.emailjs.templateId,
        {
          email: sanitizedEmail,
          code: this.verificationCode
        }
      );

      UI.showMessage('register-msg-step1', 'Verification code sent to your email!', 'success');
      UI.hideElement('register-step1');
      UI.showElement('register-step2');

      return { success: true };

    } catch (err) {
      UI.showMessage('register-msg-step1', 'Failed to send verification email: ' + err.message, 'error');
      return { success: false, error: err.message };
    }
  }

  /**
   * Step 2: Verify code
   */
  verifyCode(code) {
    const trimmedCode = code.trim();

    if (trimmedCode === this.verificationCode) {
      UI.hideElement('register-step2');
      UI.showElement('register-step3');
      UI.hideMessage('register-msg-step2');
      return { success: true };
    } else {
      UI.showMessage('register-msg-step2', 'Incorrect verification code. Please try again.', 'error');
      return { success: false };
    }
  }

  /**
   * Step 3: Complete registration
   */
  async completeRegistration(password, password2, name) {
    const sanitizedName = Sanitizer.sanitizeText(name);
    
    // Validate inputs
    const validation = Validation.validateRegistrationStep3(password, password2, sanitizedName);
    if (!validation.isValid) {
      UI.showMessage('register-msg-step3', validation.errors.join(' '), 'error');
      return { success: false };
    }

    try {
      UI.showMessage('register-msg-step3', 'Creating your account...', 'info');

      // Create Firebase auth user
      const result = await this.auth.createUserWithEmailAndPassword(this.tempEmail, password);
      const user = result.user;

      // Update display name
      await user.updateProfile({ displayName: sanitizedName });

      // Get industry code data
      const codeDoc = await this.db.collection('industryCodes').doc(this.tempIndustryCode).get();
      const codeData = codeDoc.data();

      const industryName = codeData.industryName || 'Default Industry';
      const specifications = codeData.specifications || {};
      const productName = codeData.productName || 'Default Product';

      // Determine default template/style
      const defaultStyle = specifications.style && specifications.style.length > 0 
        ? specifications.style[0] 
        : 'modern';

      // Create user document in Firestore
      await this.db.collection('users').doc(user.uid).set({
        email: this.tempEmail,
        name: sanitizedName,
        role: 'client',
        industryCode: this.tempIndustryCode,
        industryName: industryName,
        template: defaultStyle,
        specifications: specifications,
        productName: productName,
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      });

      // Mark industry code as used
      await FirebaseHelper.markIndustryCodeUsed(this.db, this.tempIndustryCode, user.uid);

      UI.showMessage('register-msg-step3', 'Account created successfully! Redirecting...', 'success');

      // Clear temporary data
      this.tempEmail = null;
      this.tempIndustryCode = null;
      this.verificationCode = null;

      return { success: true };

    } catch (err) {
      let errorMessage = 'Registration failed: ' + err.message;
      
      if (err.code === 'auth/email-already-in-use') {
        errorMessage = 'An account with this email already exists.';
      } else if (err.code === 'auth/weak-password') {
        errorMessage = 'Password is too weak. Please use a stronger password.';
      }
      
      UI.showMessage('register-msg-step3', errorMessage, 'error');
      return { success: false, error: errorMessage };
    }
  }

  /**
   * Go back to step 1
   */
  backToStep1() {
    UI.hideElement('register-step2');
    UI.showElement('register-step1');
    UI.hideMessage('register-msg-step2');
  }

  /**
   * Go back to step 2
   */
  backToStep2() {
    UI.hideElement('register-step3');
    UI.showElement('register-step2');
    UI.hideMessage('register-msg-step3');
  }

  /**
   * Reset registration flow
   */
  reset() {
    this.tempEmail = null;
    this.tempIndustryCode = null;
    this.verificationCode = null;
    
    UI.showElement('register-step1');
    UI.hideElement('register-step2');
    UI.hideElement('register-step3');
    UI.hideMessage('register-msg-step1');
    UI.hideMessage('register-msg-step2');
    UI.hideMessage('register-msg-step3');
    
    document.getElementById('register-form')?.reset();
  }
}