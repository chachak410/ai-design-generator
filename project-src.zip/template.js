/**
 * Template Module
 * Handles template loading, selection, and display
 */

import { UI } from '../../utils/ui.js';
import { FirebaseHelper } from '../../utils/firebase.js';

export class Template {
  constructor(auth, db) {
    this.auth = auth;
    this.db = db;
    this.userTemplates = [];
    this.userSpecs = null;
    this.selectedSpecs = {};
  }

  /**
   * Load user templates based on role
   */
  async loadTemplates() {
    const currentUser = this.auth.getCurrentUser();
    const userRole = this.auth.getUserRole();

    if (!currentUser) {
      UI.showMessage('template-status', 'Please sign in to view templates.', 'error');
      return;
    }

    try {
      if (userRole === 'master') {
        // Master account: all templates available
        this.userTemplates = ['modern', 'classic', 'minimalist', 'luxury', 'eco'];
        this.userSpecs = null;
        this.selectedSpecs = {};
      } else {
        // Client account: load from Firestore
        const userData = await FirebaseHelper.getUserData(this.db, currentUser.uid);

        if (!userData) {
          UI.showMessage('template-status', 'Profile not found. Please complete setup.', 'error');
          UI.showPage('setup-page', userRole);
          return;
        }

        this.userTemplates = userData.template ? [userData.template] : [];
        this.userSpecs = userData.specifications || {};

        // Initialize selected specs with first value of each
        this.selectedSpecs = Object.keys(this.userSpecs).reduce((acc, key) => {
          acc[key] = this.userSpecs[key][0] || '';
          return acc;
        }, {});

        // Update product name in auth
        if (userData.productName) {
          this.auth.setUserProductName(userData.productName);
        }
      }

      this.renderTemplateCheckboxes();
      this.renderSpecificationSelects();
      this.updateProductDisplay();
      this.updatePromptDisplay();
      this.setupEventListeners();

      UI.checkProductWarning(this.auth.getUserProductName());

    } catch (err) {
      UI.showMessage('template-status', 'Error loading templates: ' + err.message, 'error');
    }
  }

  /**
   * Render template checkboxes
   */
  renderTemplateCheckboxes() {
    const checkboxContainer = document.getElementById('template-checkboxes');
    if (!checkboxContainer) return;

    checkboxContainer.innerHTML = this.userTemplates.map(template => `
      <label>
        <input type="checkbox" value="${template}" checked>
        ${template.charAt(0).toUpperCase() + template.slice(1)}
      </label>
    `).join('');
  }

  /**
   * Render specification select dropdowns
   */
  renderSpecificationSelects() {
    const specContainer = document.getElementById('spec-selections');
    if (!specContainer) return;

    if (!this.userSpecs || Object.keys(this.userSpecs).length === 0) {
      specContainer.innerHTML = '';
      return;
    }

    specContainer.innerHTML = Object.entries(this.userSpecs).map(([key, values]) => `
      <div class="form-group">
        <label for="spec-select-${key}">
          ${key.charAt(0).toUpperCase() + key.slice(1)}
        </label>
        <select id="spec-select-${key}" data-spec-key="${key}">
          ${values.map(value => `
            <option value="${value}">${value}</option>
          `).join('')}
        </select>
      </div>
    `).join('');
  }

  /**
   * Update product display
   */
  updateProductDisplay() {
    const productDisplay = document.getElementById('product-display');
    const productName = this.auth.getUserProductName();

    if (productDisplay && productName) {
      productDisplay.textContent = `Product: ${productName}`;
      UI.showElement('product-display');
    }
  }

  /**
   * Update prompt display based on selections
   */
  updatePromptDisplay() {
    const selectedTemplates = this.getSelectedTemplates();
    const productName = this.auth.getUserProductName();

    let extra = '';
    if (this.userSpecs && Object.keys(this.selectedSpecs).length > 0) {
      extra = Object.entries(this.selectedSpecs)
        .map(([key, value]) => `${key}: ${value}`)
        .join(', ');
      if (extra) extra = ', ' + extra;
    }

    const promptDisplay = document.getElementById('prompt-display');
    if (promptDisplay) {
      if (selectedTemplates.length > 0 && productName) {
        promptDisplay.textContent = 
          `Generate a design for ${productName} in ${selectedTemplates.join(', ')} style${extra}`;
      } else if (!productName) {
        promptDisplay.textContent = 'Please set your product name in Account Settings.';
      } else {
        promptDisplay.textContent = 'Please select at least one template.';
      }
      UI.showElement('prompt-display');
    }
  }

  /**
   * Setup event listeners for template and spec changes
   */
  setupEventListeners() {
    // Template checkbox changes
    document.querySelectorAll('#template-checkboxes input').forEach(checkbox => {
      checkbox.addEventListener('change', () => {
        this.updatePromptDisplay();
      });
    });

    // Specification select changes
    document.querySelectorAll('#spec-selections select').forEach(select => {
      select.addEventListener('change', (e) => {
        const specKey = e.target.dataset.specKey;
        this.selectedSpecs[specKey] = e.target.value;
        this.updatePromptDisplay();
      });
    });
  }

  /**
   * Get selected templates
   */
  getSelectedTemplates() {
    return Array.from(document.querySelectorAll('#template-checkboxes input:checked'))
      .map(input => input.value);
  }

  /**
   * Get selected specifications
   */
  getSelectedSpecs() {
    return { ...this.selectedSpecs };
  }

  /**
   * Get user templates
   */
  getUserTemplates() {
    return [...this.userTemplates];
  }
}