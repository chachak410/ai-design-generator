/**
 * Authentication Module
 * Handles login, logout, and user session management
 */

import { UI } from '../../utils/ui.js';
import { Validation } from '../../utils/validation.js';
import { Sanitizer } from '../../utils/sanitizer.js';
import { FirebaseHelper } from '../../utils/firebase.js';

export class Auth {
  constructor() {
    this.auth = null;
    this.db = null;
    this.currentUser = null;
    this.userRole = null;
    this.userProductName = '';
    this.userIndustryCode = null;
  }

  /**
   * Initialize the auth module
   */
  init(firebaseAuth, firebaseDb) {
    this.auth = firebaseAuth;
    this.db = firebaseDb;
    this.setupAuthStateListener();
  }

  /**
   * Setup Firebase auth state listener
   */
  setupAuthStateListener() {
    this.auth.onAuthStateChanged(async (user) => {
      if (user) {
        this.currentUser = user;
        await this.checkUserRole();
        await this.loadUserData();
        this.showMainApp();
      } else {
        this.resetState();
        UI.showAuth();
        UI.showLogin();
      }
    });
  }

  /**
   * Handle user login
   */
  async login(email, password) {
    const sanitizedEmail = Sanitizer.sanitizeEmail(email);
    const validation = Validation.validateLogin(sanitizedEmail, password);

    if (!validation.isValid) {
      UI.showMessage('login-msg', validation.errors.join(' '), 'error');
      return { success: false };
    }

    try {
      UI.showMessage('login-msg', 'Signing in...', 'info');
      
      const result = await this.auth.signInWithEmailAndPassword(sanitizedEmail, password);
      this.currentUser = result.user;
      
      await this.checkUserRole();
      await this.loadUserData();
      
      UI.hideMessage('login-msg');
      
      return { success: true };
      
    } catch (err) {
      let errorMessage = 'Login failed. Please try again.';
      
      if (err.code === 'auth/invalid-login-credentials' || err.code === 'auth/wrong-password') {
        errorMessage = 'Incorrect email or password.';
      } else if (err.code === 'auth/user-not-found') {
        errorMessage = 'No account found with this email.';
      } else if (err.code === 'auth/too-many-requests') {
        errorMessage = 'Too many failed attempts. Please try again later.';
      }
      
      UI.showMessage('login-msg', errorMessage, 'error');
      return { success: false, error: errorMessage };
    }
  }

  /**
   * Handle password reset
   */
  async resetPassword(email) {
    const sanitizedEmail = Sanitizer.sanitizeEmail(email);
    
    if (!sanitizedEmail || !Sanitizer.isValidEmail(sanitizedEmail)) {
      UI.showMessage('login-msg', 'Please enter a valid email address.', 'error');
      return { success: false };
    }

    try {
      await this.auth.sendPasswordResetEmail(sanitizedEmail);
      UI.showMessage('login-msg', 'Password reset email sent! Check your inbox.', 'success');
      return { success: true };
    } catch (err) {
      UI.showMessage('login-msg', 'Error: ' + err.message, 'error');
      return { success: false, error: err.message };
    }
  }

  /**
   * Handle user logout
   */
  async logout() {
    try {
      await this.auth.signOut();
      this.resetState();
      UI.showAuth();
      UI.showLogin();
      return { success: true };
    } catch (err) {
      UI.showMessage('template-status', 'Logout failed. Please try again.', 'error');
      return { success: false, error: err.message };
    }
  }

  /**
   * Check user role (master or client)
   */
  async checkUserRole() {
    // Master account check
    if (this.currentUser.email === 'langtechgroup5@gmail.com') {
      this.userRole = 'master';
      return;
    }

    // Get role from Firestore
    const userData = await FirebaseHelper.getUserData(this.db, this.currentUser.uid);
    this.userRole = userData?.role || 'client';
    this.userIndustryCode = userData?.industryCode || null;
  }

  /**
   * Load user data from Firestore
   */
  async loadUserData() {
    const userData = await FirebaseHelper.getUserData(this.db, this.currentUser.uid);
    
    if (userData) {
      this.userProductName = userData.productName || '';
      this.userIndustryCode = userData.industryCode || null;
    }
  }

  /**
   * Show main app after successful login
   */
  showMainApp() {
    UI.showMainApp();
    UI.toggleMasterUI(this.userRole === 'master');
    UI.checkProductWarning(this.userProductName);

    // Check if user needs to complete setup
    const needsSetup = this.currentUser && 
                      (!this.currentUser.displayName || 
                       !this.userProductName || 
                       this.userProductName.trim().length < 2);

    if (needsSetup) {
      UI.showPage('setup-page', this.userRole);
    } else {
      UI.showPage('template-page', this.userRole);
    }
  }

  /**
   * Reset auth state
   */
  resetState() {
    this.currentUser = null;
    this.userRole = null;
    this.userProductName = '';
    this.userIndustryCode = null;
  }

  /**
   * Get current user
   */
  getCurrentUser() {
    return this.currentUser;
  }

  /**
   * Get user role
   */
  getUserRole() {
    return this.userRole;
  }

  /**
   * Get user product name
   */
  getUserProductName() {
    return this.userProductName;
  }

  /**
   * Get user industry code
   */
  getUserIndustryCode() {
    return this.userIndustryCode;
  }

  /**
   * Update user product name
   */
  setUserProductName(productName) {
    this.userProductName = productName;
    UI.checkProductWarning(this.userProductName);
  }
}

// Create singleton instance
export const authInstance = new Auth();