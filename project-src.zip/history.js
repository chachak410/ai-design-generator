/**
 * Generation History Module
 * Handles loading and displaying past generation records
 */

import { UI } from '../../utils/ui.js';
import { FirebaseHelper } from '../../utils/firebase.js';
import { Helpers } from '../../utils/helpers.js';

export class History {
  constructor(auth, db) {
    this.auth = auth;
    this.db = db;
  }

  /**
   * Load and display generation records
   */
  async loadRecords(limit = 3) {
    const currentUser = this.auth.getCurrentUser();
    const recordsList = document.getElementById('records-list');

    if (!recordsList) {
      console.error('Records list element not found');
      return;
    }

    if (!currentUser) {
      UI.showMessage('records-msg', 'Please sign in to view records.', 'error');
      return;
    }

    // Clear existing records
    recordsList.innerHTML = '';

    try {
      UI.showMessage('records-msg', 'Loading records...', 'info');

      // Get generation records from Firestore
      const records = await FirebaseHelper.getGenerationRecords(
        this.db, 
        currentUser.uid, 
        limit
      );

      if (records.length === 0) {
        UI.showMessage('records-msg', 'No generation records found. Start creating designs!', 'info');
        return;
      }

      // Render records
      records.forEach(record => {
        this.renderRecord(record, recordsList);
      });

      UI.hideMessage('records-msg');

    } catch (err) {
      console.error('Error loading records:', err);
      UI.showMessage('records-msg', 'Error loading records: ' + err.message, 'error');
    }
  }

  /**
   * Render a single generation record
   */
  renderRecord(record, container) {
    const templates = record.templates || [];
    const images = record.images || [];
    const createdAt = record.createdAt ? Helpers.formatDate(record.createdAt) : 'Unknown date';

    images.forEach((image, idx) => {
      const card = document.createElement('div');
      card.className = 'record-card';

      card.innerHTML = `
        <div class="record-header">
          <span class="record-badge">${templates.join(', ')}</span>
          <span class="record-provider">${image.provider}</span>
        </div>
        <img 
          src="${image.url}" 
          alt="Generated design ${idx + 1}" 
          loading="lazy"
          onload="this.style.opacity=1" 
          style="opacity:0.5; transition:opacity 0.5s"
        />
        <div class="record-footer">
          <span class="record-date">${createdAt}</span>
          <button class="btn btn-download" data-url="${image.url}" data-idx="${idx}">
            Download
          </button>
        </div>
      `;

      // Add download button listener
      const downloadBtn = card.querySelector('.btn-download');
      downloadBtn.addEventListener('click', () => {
        Helpers.downloadImage(image.url, `design-${record.id}-${idx + 1}.png`);
        UI.showMessage('records-msg', 'Image downloaded!', 'success');
      });

      container.appendChild(card);
    });
  }

  /**
   * Load more records (pagination)
   */
  async loadMore(currentCount) {
    const currentUser = this.auth.getCurrentUser();
    
    if (!currentUser) return;

    try {
      const moreRecords = await this.db.collection('generations')
        .where('userId', '==', currentUser.uid)
        .orderBy('createdAt', 'desc')
        .limit(3)
        .offset(currentCount)
        .get();

      const recordsList = document.getElementById('records-list');
      
      moreRecords.forEach(doc => {
        const record = { id: doc.id, ...doc.data() };
        this.renderRecord(record, recordsList);
      });

      return moreRecords.docs.length;

    } catch (err) {
      console.error('Error loading more records:', err);
      return 0;
    }
  }

  /**
   * Delete a generation record
   */
  async deleteRecord(recordId) {
    const currentUser = this.auth.getCurrentUser();
    
    if (!currentUser) return { success: false };

    try {
      await this.db.collection('generations').doc(recordId).delete();
      return { success: true };
    } catch (err) {
      console.error('Error deleting record:', err);
      return { success: false, error: err.message };
    }
  }
}