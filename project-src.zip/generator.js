/**
 * Image Generation Module
 * Main orchestrator for image generation
 */

import { UI } from '../../utils/ui.js';
import { Sanitizer } from '../../utils/sanitizer.js';
import { FirebaseHelper } from '../../utils/firebase.js';
import { Pollinations } from './pollinations.js';
import { Stability } from './stability.js';
import { Renderer } from './renderer.js';

export class Generator {
  constructor(auth, db, template) {
    this.auth = auth;
    this.db = db;
    this.template = template;
    this.pollinations = new Pollinations();
    this.stability = new Stability();
    this.renderer = new Renderer();
    this.generationCount = 0;
    this.maxGenerations = 20;
    this.currentLanguage = 'en';
  }

  /**
   * Set current language for prompts
   */
  setLanguage(lang) {
    this.currentLanguage = lang;
  }

  /**
   * Main image generation function
   */
  async generateImages() {
    const currentUser = this.auth.getCurrentUser();
    const productName = this.auth.getUserProductName();

    // Validation checks
    if (!currentUser) {
      UI.showMessage('template-status', 'Please sign in to generate images.', 'error');
      return;
    }

    if (!productName || productName.trim().length < 2) {
      UI.showMessage('template-status', 'Please set your product name in Account Settings.', 'error');
      return;
    }

    const selectedTemplates = this.template.getSelectedTemplates();
    if (selectedTemplates.length === 0) {
      UI.showMessage('template-status', 'Please select at least one template.', 'error');
      return;
    }

    if (this.generationCount >= this.maxGenerations) {
      UI.showMessage('template-status', 'Maximum generation limit (20) reached for this session.', 'error');
      return;
    }

    // Build prompt
    const prompt = this.buildPrompt(productName, selectedTemplates);
    
    UI.showMessage('template-status', 'Generating images with AI...', 'info');
    
    const generateBtn = document.getElementById('generate-images-btn');
    if (generateBtn) generateBtn.disabled = true;

    try {
      const images = await this.generateImagePair(prompt);

      if (images.length === 2) {
        // Render images
        this.renderer.renderImages(images);

        // Save to Firestore
        await this.saveGenerationRecord(currentUser.uid, {
          templates: selectedTemplates,
          productName: productName,
          specifications: this.template.getSelectedSpecs(),
          images: images.map(img => ({ 
            provider: img.provider, 
            url: img.url 
          }))
        });

        UI.showMessage('template-status', 'Images generated successfully!', 'success');
      } else {
        UI.showMessage('template-status', `Generated ${images.length}/2 images. Please try again.`, 'error');
      }

    } catch (err) {
      UI.showMessage('template-status', 'Error generating images: ' + err.message, 'error');
      console.error('Generation error:', err);
    } finally {
      if (generateBtn) generateBtn.disabled = false;
    }
  }

  /**
   * Build prompt based on language and selections
   */
  buildPrompt(productName, templates) {
    const specs = this.template.getSelectedSpecs();
    let extra = '';

    if (specs && Object.keys(specs).length > 0) {
      extra = Object.entries(specs)
        .map(([key, value]) => `${key}: ${value}`)
        .join(', ');
      if (extra) extra = ', ' + extra;
    }

    let basePrompt = '';

    if (this.currentLanguage === 'zh') {
      basePrompt = `一个精美的${productName}产品设计图，${templates.join('、')}风格${extra}，高质量，细节丰富，专业级`;
    } else if (this.currentLanguage === 'yue') {
      basePrompt = `一個精美嘅${productName}產品設計圖，${templates.join('、')}風格${extra}，高質量，細節豐富，專業級`;
    } else {
      basePrompt = `A beautiful product design for ${productName}, ${templates.join(', ')} style${extra}, high quality, detailed, professional`;
    }

    return Sanitizer.sanitizePrompt(basePrompt);
  }

  /**
   * Generate a pair of images
   */
  async generateImagePair(basePrompt) {
    const seed = Date.now();
    const images = [];
    let attempts = 0;
    const maxAttempts = 10;

    while (images.length < 2 && attempts < maxAttempts && this.generationCount < this.maxGenerations) {
      const prompt = images.length === 0 
        ? basePrompt 
        : `${basePrompt} (variation ${images.length + 1})`;

      try {
        // Try Pollinations first
        const image = await this.pollinations.generate(prompt, seed + attempts, 768, 1024);
        
        if (image) {
          images.push(image);
          this.generationCount++;
        } else if (images.length === 0) {
          // Fallback to Stability only for first image if Pollinations fails
          const backupImage = await this.stability.generate(prompt, seed + attempts, 1024, 1024);
          if (backupImage) {
            images.push(backupImage);
            this.generationCount++;
          }
        }
      } catch (err) {
        console.error(`Generation attempt ${attempts + 1} failed:`, err);
      }

      attempts++;
    }

    return images;
  }

  /**
   * Save generation record to Firestore
   */
  async saveGenerationRecord(uid, data) {
    try {
      await FirebaseHelper.saveGenerationRecord(this.db, uid, data);
    } catch (err) {
      console.error('Error saving generation record:', err);
      // Don't throw - generation was successful even if save failed
    }
  }

  /**
   * Reset generation count
   */
  resetGenerationCount() {
    this.generationCount = 0;
  }

  /**
   * Get current generation count
   */
  getGenerationCount() {
    return this.generationCount;
  }
}