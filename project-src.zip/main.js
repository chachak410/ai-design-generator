/**
 * Main Application - Simplified Version
 * Testing modular approach step by step
 */

// Simple inline config (avoid import issues for now)
const config = {
  firebase: {
    apiKey: "AIzaSyC0P-rmy6ZiKCBnivZQBahKWaPcqg4nDnU",
    authDomain: "image-generator-c51e2.firebaseapp.com",
    projectId: "image-generator-c51e2",
    storageBucket: "image-generator-c51e2.firebasestorage.app",
    messagingSenderId: "222706847155",
    appId: "1:222706847155:web:824453eca61077f5f0cfc6",
    measurementId: "G-JSK1FHFEMT"
  },
  emailjs: {
    serviceId: 'service_sq0910p',
    templateId: 'template_6cykjb4',
    userId: 'DjaueAhkuIzk5gj2x'
  },
  api: {
    stability: 'sk-RwqmAp2Q9nr3RgoLh8g04tgrprjlGhrDMYD8JGv1IxF9WnLQ'
  }
};

// Simple UI utilities (inline for now)
const UI = {
  showElement(id) {
    const el = document.getElementById(id);
    if (el) {
      el.classList.remove('hidden');
      el.style.display = 'block';
    }
  },

  hideElement(id) {
    const el = document.getElementById(id);
    if (el) {
      el.classList.add('hidden');
      el.style.display = 'none';
    }
  },

  showMessage(id, message, type = 'info') {
    const el = document.getElementById(id);
    if (el) {
      el.innerHTML = message;
      el.className = `message ${type}`;
      el.style.display = 'block';
    }
  },

  hideMessage(id) {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  },

  showLogin() {
    this.showElement('login-form');
    this.hideElement('register-form');
    this.showElement('switch-to-register');
    this.hideElement('switch-to-login');
    this.hideMessage('login-msg');
  },

  showRegister() {
    this.hideElement('login-form');
    this.showElement('register-form');
    this.hideElement('switch-to-register');
    this.showElement('switch-to-login');
    this.showElement('register-step1');
    this.hideElement('register-step2');
    this.hideElement('register-step3');
    document.getElementById('register-form')?.reset();
    this.hideMessage('register-msg-step1');
    this.hideMessage('register-msg-step2');
    this.hideMessage('register-msg-step3');
  },

  showMainApp() {
    const authContainer = document.getElementById('auth-container');
    const mainApp = document.getElementById('main-app');
    if (authContainer && mainApp) {
      authContainer.style.display = 'none';
      mainApp.classList.add('show');
    }
  },

  showAuth() {
    const authContainer = document.getElementById('auth-container');
    const mainApp = document.getElementById('main-app');
    if (authContainer && mainApp) {
      authContainer.style.display = 'block';
      mainApp.classList.remove('show');
    }
  },

  showPage(pageId, userRole = null) {
    const pages = [
      'setup-page', 
      'account-page', 
      'template-page', 
      'records-page', 
      'create-account-page'
    ];

    // Access control for create-account-page
    if (pageId === 'create-account-page' && userRole !== 'master') {
      this.showMessage('template-status', 'Access denied: Only master accounts can create industry codes.', 'error');
      pageId = 'template-page';
    }

    pages.forEach(id => this.hideElement(id));
    this.showElement(pageId);
  },

  checkProductWarning(productName) {
    const warning = document.getElementById('product-warning');
    if (warning) {
      if (productName && productName.trim().length >= 2) {
        this.hideElement('product-warning');
      } else {
        this.showElement('product-warning');
      }
    }
  },

  toggleMasterUI(isMaster) {
    if (isMaster) {
      this.showElement('create-account-link');
    } else {
      this.hideElement('create-account-link');
    }
  }
};

const LoadingUI = {
  show(elementId, message = 'Loading...') {
    const el = document.getElementById(elementId);
    if (!el) return;
    
    el.innerHTML = `
      <div class="loading-spinner">
        <div class="spinner"></div>
        <p>${message}</p>
      </div>
    `;
    el.style.display = 'block';
  },

  hide(elementId) {
    const el = document.getElementById(elementId);
    if (el) el.style.display = 'none';
  }
};

// Global state
let auth = null;
let db = null;
let currentUser = null;
let userRole = null;
let userProductName = '';
let userSpecs = null;
let userTemplates = [];
let selectedSpecs = {};
let generationCount = 0;
let registrationTemp = {
  email: null,
  industryCode: null,
  verificationCode: null
};

// Update generation counter
function updateGenerationCounter() {
  const counter = document.getElementById('generation-counter');
  if (counter) {
    counter.textContent = `Generations: ${generationCount}/20`;
    if (generationCount >= 18) {
      counter.style.color = '#e74c3c';
    } else if (generationCount >= 15) {
      counter.style.color = '#f39c12';
    } else {
      counter.style.color = '#666';
    }
  }
}

// Session management
function updateGenerationCounter() {
  const counter = document.getElementById('generation-counter');
  if (counter) {
    counter.textContent = `Generations: ${generationCount}/20`;
    if (generationCount >= 18) {
      counter.style.color = '#e74c3c';
    } else if (generationCount >= 15) {
      counter.style.color = '#f39c12';
    } else {
      counter.style.color = '#666';
    }
  }
}

// Language switching function
function setLang(lang) {
  if (window.i18n && window.i18n.setLanguage) {
    window.i18n.setLanguage(lang);
    localStorage.setItem('userLanguage', lang);
    console.log(`Language changed to: ${lang}`);
  } else {
    console.warn('i18n not available');
  }
}

// Initialize Firebase
function initFirebase() {
  try {
    firebase.initializeApp(config.firebase);
    auth = firebase.auth();
    db = firebase.firestore();
    console.log('Firebase initialized');
    
    // Setup auth listener
    auth.onAuthStateChanged(async (user) => {
      if (user) {
        currentUser = user;
        console.log('User signed in:', user.email);
        
        // Check user role
        await checkUserRole();
        await loadUserData();
        
        UI.showMainApp();
        UI.toggleMasterUI(userRole === 'master');
        UI.checkProductWarning(userProductName);
        
        // Check if user needs setup
        const needsSetup = !user.displayName || !userProductName || userProductName.trim().length < 2;
        
        if (needsSetup) {
          showPage('setup-page');
        } else {
          showPage('template-page');
        }
        
      } else {
        currentUser = null;
        userRole = null;
        userProductName = '';
        console.log('User signed out');
        UI.showAuth();
        UI.showLogin();
      }
    });
  } catch (err) {
    console.error('Firebase init error:', err);
    alert('Failed to initialize Firebase: ' + err.message);
  }
}

// Check user role
async function checkUserRole() {
  // Master account check
  if (currentUser.email === 'langtechgroup5@gmail.com') {
    userRole = 'master';
    return;
  }

  // Get role from Firestore
  try {
    const doc = await db.collection('users').doc(currentUser.uid).get();
    if (doc.exists) {
      userRole = doc.data().role || 'client';
    } else {
      userRole = 'client';
    }
  } catch (err) {
    console.error('Error checking user role:', err);
    userRole = 'client';
  }
}

// Load user data
async function loadUserData() {
  try {
    const doc = await db.collection('users').doc(currentUser.uid).get();
    if (doc.exists) {
      const data = doc.data();
      userProductName = data.productName || '';
      userSpecs = data.specifications || {};
      userTemplates = data.template ? [data.template] : [];
    }
  } catch (err) {
    console.error('Error loading user data:', err);
  }
}

// Initialize EmailJS
function initEmailJS() {
  try {
    emailjs.init(config.emailjs.userId);
    console.log('EmailJS initialized');
  } catch (err) {
    console.error('EmailJS init error:', err);
  }
}

// Login function
async function handleLogin(email, password) {
  try {
    UI.showMessage('login-msg', 'Signing in...', 'info');
    await auth.signInWithEmailAndPassword(email, password);
    UI.hideMessage('login-msg');
  } catch (err) {
    console.error('Login error:', err);
    let errorMessage = 'Login failed. Please try again.';
    if (err.code === 'auth/invalid-login-credentials' || err.code === 'auth/wrong-password') {
      errorMessage = 'Incorrect email or password.';
    } else if (err.code === 'auth/user-not-found') {
      errorMessage = 'No account found with this email.';
    }
    UI.showMessage('login-msg', errorMessage, 'error');
  }
}

// Logout function
async function handleLogout() {
  try {
    await auth.signOut();
  } catch (err) {
    console.error('Logout error:', err);
    alert('Logout failed: ' + err.message);
  }
}

// Send verification code
async function sendVerificationCode() {
  const email = document.getElementById('register-email')?.value.trim();
  const industryCode = document.getElementById('register-industry-code')?.value.trim().toUpperCase();

  if (!email || !industryCode) {
    UI.showMessage('register-msg-step1', 'Please enter email and industry code.', 'error');
    return;
  }

  try {
    UI.showMessage('register-msg-step1', 'Checking industry code...', 'info');
    
    // Check if industry code exists and is not used
    const codeDoc = await db.collection('industryCodes').doc(industryCode).get();
    
    if (!codeDoc.exists) {
      UI.showMessage('register-msg-step1', 'Invalid industry code.', 'error');
      return;
    }
    
    if (codeDoc.data().used) {
      UI.showMessage('register-msg-step1', 'This industry code has already been used.', 'error');
      return;
    }

    // Generate verification code
    registrationTemp.verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
    registrationTemp.email = email;
    registrationTemp.industryCode = industryCode;

    UI.showMessage('register-msg-step1', 'Sending verification code...', 'info');

    // Send email
    await emailjs.send(
      config.emailjs.serviceId,
      config.emailjs.templateId,
      {
        email: email,
        code: registrationTemp.verificationCode
      }
    );

    UI.showMessage('register-msg-step1', 'Verification code sent to your email!', 'success');
    UI.hideElement('register-step1');
    UI.showElement('register-step2');

  } catch (err) {
    console.error('Send code error:', err);
    UI.showMessage('register-msg-step1', 'Failed to send email: ' + err.message, 'error');
  }
}

// Verify code
function verifyCode() {
  const code = document.getElementById('register-code')?.value.trim();
  
  if (code === registrationTemp.verificationCode) {
    UI.hideElement('register-step2');
    UI.showElement('register-step3');
    UI.hideMessage('register-msg-step2');
  } else {
    UI.showMessage('register-msg-step2', 'Incorrect verification code.', 'error');
  }
}

// Complete registration
async function completeRegistration() {
  const password = document.getElementById('register-password')?.value;
  const password2 = document.getElementById('register-password2')?.value;
  const name = document.getElementById('register-name')?.value.trim();

  if (password !== password2) {
    UI.showMessage('register-msg-step3', 'Passwords do not match.', 'error');
    return;
  }

  if (password.length < 6) {
    UI.showMessage('register-msg-step3', 'Password must be at least 6 characters.', 'error');
    return;
  }

  try {
    UI.showMessage('register-msg-step3', 'Creating account...', 'info');

    // Create Firebase auth user
    const result = await auth.createUserWithEmailAndPassword(registrationTemp.email, password);
    const user = result.user;

    // Update display name
    await user.updateProfile({ displayName: name });

    // Get industry code data
    const codeDoc = await db.collection('industryCodes').doc(registrationTemp.industryCode).get();
    const codeData = codeDoc.data();

    // Create user document
    await db.collection('users').doc(user.uid).set({
      email: registrationTemp.email,
      name: name,
      role: 'client',
      industryCode: registrationTemp.industryCode,
      industryName: codeData.industryName || 'Default Industry',
      template: codeData.specifications?.style?.[0] || 'modern',
      specifications: codeData.specifications || {},
      productName: codeData.productName || 'Default Product',
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    // Mark industry code as used
    await db.collection('industryCodes').doc(registrationTemp.industryCode).update({
      used: true,
      usedBy: user.uid,
      usedAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    UI.showMessage('register-msg-step3', 'Account created successfully!', 'success');

    // Clear temp data
    registrationTemp = { email: null, industryCode: null, verificationCode: null };

  } catch (err) {
    console.error('Registration error:', err);
    let errorMessage = 'Registration failed: ' + err.message;
    if (err.code === 'auth/email-already-in-use') {
      errorMessage = 'An account with this email already exists.';
    }
    UI.showMessage('register-msg-step3', errorMessage, 'error');
  }
}

// Show page function
function showPage(pageId) {
  UI.showPage(pageId, userRole);
  
  // Load page-specific data
  if (pageId === 'account-page') {
    loadAccountInfo();
  } else if (pageId === 'template-page') {
    loadTemplates();
  } else if (pageId === 'records-page') {
    loadRecords();
  }
}

// Load account info
async function loadAccountInfo() {
  if (!currentUser) {
    UI.showMessage('account-msg', 'Please sign in to view account information.', 'error');
    return;
  }

  try {
    const doc = await db.collection('users').doc(currentUser.uid).get();
    
    if (!doc.exists) {
      UI.showMessage('account-msg', 'Account data not found.', 'error');
      return;
    }

    const data = doc.data();
    const accountInfo = document.getElementById('account-info');
    
    if (accountInfo) {
      accountInfo.innerHTML = `
        <p><strong>Name:</strong> ${data.name || 'Not set'}</p>
        <p><strong>Email:</strong> ${currentUser.email}</p>
        <p><strong>Industry:</strong> ${data.industryName || 'Not specified'} (Code: ${data.industryCode || '000000'})</p>
        <p><strong>Template:</strong> ${data.template || 'None'}</p>
        <p><strong>Product Name:</strong> ${data.productName || 'Not set'}</p>
      `;
    }

    UI.checkProductWarning(data.productName);

  } catch (err) {
    UI.showMessage('account-msg', 'Error loading account: ' + err.message, 'error');
  }
}

// Load templates
async function loadTemplates() {
  if (!currentUser) {
    UI.showMessage('template-status', 'Please sign in to view templates.', 'error');
    return;
  }

  try {
    if (userRole === 'master') {
      // Master: all templates
      userTemplates = ['modern', 'classic', 'minimalist', 'luxury', 'eco'];
      userSpecs = null;
      selectedSpecs = {};
    } else {
      // Client: load from user data
      const doc = await db.collection('users').doc(currentUser.uid).get();
      
      if (!doc.exists) {
        UI.showMessage('template-status', 'Profile not found.', 'error');
        showPage('setup-page');
        return;
      }

      const data = doc.data();
      userTemplates = data.template ? [data.template] : [];
      userSpecs = data.specifications || {};
      userProductName = data.productName || '';

      // Initialize selected specs
      selectedSpecs = Object.keys(userSpecs).reduce((acc, key) => {
        acc[key] = userSpecs[key][0] || '';
        return acc;
      }, {});
    }

    renderTemplateUI();
    updatePromptDisplay();

  } catch (err) {
    UI.showMessage('template-status', 'Error loading templates: ' + err.message, 'error');
  }
}

// Render template UI
function renderTemplateUI() {
  // Render checkboxes
  const checkboxContainer = document.getElementById('template-checkboxes');
  if (checkboxContainer) {
    checkboxContainer.innerHTML = userTemplates.map(template => `
      <label>
        <input type="checkbox" value="${template}" checked>
        ${template.charAt(0).toUpperCase() + template.slice(1)}
      </label>
    `).join('');

    // Add change listeners
    checkboxContainer.querySelectorAll('input').forEach(cb => {
      cb.addEventListener('change', updatePromptDisplay);
    });
  }

  // Render specifications
  const specContainer = document.getElementById('spec-selections');
  if (specContainer) {
    if (!userSpecs || Object.keys(userSpecs).length === 0) {
      specContainer.innerHTML = '';
    } else {
      specContainer.innerHTML = Object.entries(userSpecs).map(([key, values]) => `
        <div class="form-group">
          <label for="spec-select-${key}">
            ${key.charAt(0).toUpperCase() + key.slice(1)}
          </label>
          <select id="spec-select-${key}" data-spec-key="${key}">
            ${values.map(value => `<option value="${value}">${value}</option>`).join('')}
          </select>
        </div>
      `).join('');

      // Add change listeners
      specContainer.querySelectorAll('select').forEach(select => {
        select.addEventListener('change', (e) => {
          selectedSpecs[e.target.dataset.specKey] = e.target.value;
          updatePromptDisplay();
        });
      });
    }
  }

  // Show product name
  const productDisplay = document.getElementById('product-display');
  if (productDisplay && userProductName) {
    productDisplay.textContent = `Product: ${userProductName}`;
    UI.showElement('product-display');
  }
}

// Update prompt display
function updatePromptDisplay() {
  const selectedTemplates = Array.from(
    document.querySelectorAll('#template-checkboxes input:checked')
  ).map(cb => cb.value);

  let extra = '';
  if (userSpecs && Object.keys(selectedSpecs).length > 0) {
    extra = Object.entries(selectedSpecs)
      .map(([key, value]) => `${key}: ${value}`)
      .join(', ');
    if (extra) extra = ', ' + extra;
  }

  const promptDisplay = document.getElementById('prompt-display');
  if (promptDisplay) {
    if (selectedTemplates.length > 0 && userProductName) {
      promptDisplay.textContent = 
        `Generate a design for ${userProductName} in ${selectedTemplates.join(', ')} style${extra}`;
    } else if (!userProductName) {
      promptDisplay.textContent = 'Please set your product name in Account Settings.';
    } else {
      promptDisplay.textContent = 'Please select at least one template.';
    }
    UI.showElement('prompt-display');
  }
}

// Load records
async function loadRecords() {
  if (!currentUser) {
    UI.showMessage('records-msg', 'Please sign in to view records.', 'error');
    return;
  }

  const recordsList = document.getElementById('records-list');
  if (!recordsList) return;

  recordsList.innerHTML = '';

  try {
    UI.showMessage('records-msg', 'Loading records...', 'info');

    const snapshot = await db.collection('generations')
      .where('userId', '==', currentUser.uid)
      .orderBy('createdAt', 'desc')
      .limit(3)
      .get();

    if (snapshot.empty) {
      UI.showMessage('records-msg', 'No generation records found.', 'info');
      return;
    }

    snapshot.forEach(doc => {
      const data = doc.data();
      renderRecord(data, recordsList);
    });

    UI.hideMessage('records-msg');

  } catch (err) {
    console.error('Error loading records:', err);
    UI.showMessage('records-msg', 'Error loading records: ' + err.message, 'error');
  }
}

// Render a record
function renderRecord(data, container) {
  const templates = data.templates || [];
  const images = data.images || [];
  const createdAt = data.createdAt ? data.createdAt.toDate().toLocaleString() : 'Unknown';

  images.forEach((image, idx) => {
    const card = document.createElement('div');
    card.className = 'record-card';
    card.innerHTML = `
      <div class="record-header">
        <span class="record-badge">${templates.join(', ')}</span>
        <span class="record-provider">${image.provider}</span>
      </div>
      <img src="${image.url}" alt="Generated design ${idx + 1}" loading="lazy">
      <div class="record-footer">
        <span class="record-date">${createdAt}</span>
        <button class="btn btn-download" onclick="downloadImage('${image.url}', 'design-${idx}.png')">
          Download
        </button>
      </div>
    `;
    container.appendChild(card);
  });
}

// Download image helper
function downloadImage(url, filename) {
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  UI.showMessage('records-msg', 'Image downloaded!', 'success');
}

// Setup page - Handle profile setup
async function handleSetup() {
  const name = document.getElementById('setup-name')?.value.trim();
  const productName = document.getElementById('setup-product')?.value.trim();

  if (!name || name.length < 2) {
    UI.showMessage('setup-msg', 'Please enter a valid name (at least 2 characters).', 'error');
    return;
  }

  if (!productName || productName.length < 2) {
    UI.showMessage('setup-msg', 'Please enter a valid product name (at least 2 characters).', 'error');
    return;
  }

  try {
    UI.showMessage('setup-msg', 'Saving profile...', 'info');

    // Update Firestore
    await db.collection('users').doc(currentUser.uid).update({
      name: name,
      productName: productName,
      setupCompleted: true
    });

    // Update Firebase Auth display name
    await currentUser.updateProfile({ displayName: name });

    // Update global state
    userProductName = productName;

    UI.showMessage('setup-msg', 'Profile saved successfully!', 'success');

    // Navigate to template page
    setTimeout(() => {
      showPage('template-page');
    }, 1000);

  } catch (err) {
    console.error('Setup error:', err);
    UI.showMessage('setup-msg', 'Error saving profile: ' + err.message, 'error');
  }
}

// Account page - Show edit form
async function showEditAccount() {
  UI.hideElement('account-info');
  UI.hideElement('edit-account-btn');
  UI.showElement('account-form');

  try {
    const doc = await db.collection('users').doc(currentUser.uid).get();
    
    if (doc.exists) {
      const data = doc.data();
      document.getElementById('account-name').value = data.name || '';
      document.getElementById('account-product').value = data.productName || '';
      document.getElementById('account-email').value = currentUser.email;
    }
  } catch (err) {
    UI.showMessage('account-msg', 'Error loading account data: ' + err.message, 'error');
  }
}

// Account page - Cancel edit
function cancelEdit() {
  UI.hideElement('account-form');
  UI.showElement('edit-account-btn');
  UI.showElement('account-info');
  UI.hideMessage('account-msg');
}

// Account page - Update account
async function updateAccount() {
  const name = document.getElementById('account-name')?.value.trim();
  const productName = document.getElementById('account-product')?.value.trim();

  if (!name || name.length < 2) {
    UI.showMessage('account-msg', 'Please enter a valid name (at least 2 characters).', 'error');
    return;
  }

  if (!productName || productName.length < 2) {
    UI.showMessage('account-msg', 'Please enter a valid product name (at least 2 characters).', 'error');
    return;
  }

  try {
    UI.showMessage('account-msg', 'Updating profile...', 'info');

    // Update Firestore
    await db.collection('users').doc(currentUser.uid).update({
      name: name,
      productName: productName
    });

    // Update Firebase Auth display name
    await currentUser.updateProfile({ displayName: name });

    // Update global state
    userProductName = productName;

    UI.showMessage('account-msg', 'Profile updated successfully!', 'success');

    // Hide form and reload info
    cancelEdit();
    await loadAccountInfo();

  } catch (err) {
    console.error('Update account error:', err);
    UI.showMessage('account-msg', 'Error updating profile: ' + err.message, 'error');
  }
}

// Generate images
async function generateImages() {
  if (!currentUser) {
    UI.showMessage('template-status', 'Please sign in to generate images.', 'error');
    return;
  }

  if (!userProductName || userProductName.trim().length < 2) {
    UI.showMessage('template-status', 'Please set your product name in Account Settings.', 'error');
    return;
  }

  const selectedTemplates = Array.from(
    document.querySelectorAll('#template-checkboxes input:checked')
  ).map(cb => cb.value);

  if (selectedTemplates.length === 0) {
    UI.showMessage('template-status', 'Please select at least one template.', 'error');
    return;
  }

  if (generationCount >= 20) {
    UI.showMessage('template-status', 'Maximum generation limit (20) reached for this session.', 'error');
    return;
  }

  // Build prompt
  let extra = '';
  if (userSpecs && Object.keys(selectedSpecs).length > 0) {
    extra = Object.entries(selectedSpecs)
      .map(([key, value]) => `${key}: ${value}`)
      .join(', ');
    if (extra) extra = ', ' + extra;
  }

  const prompt = `A beautiful product design for ${userProductName}, ${selectedTemplates.join(', ')} style${extra}, high quality, detailed, professional`;

  // Show progress
  const progressMsg = document.createElement('div');
  progressMsg.id = 'generation-progress';
  progressMsg.className = 'message info';
  progressMsg.innerHTML = `
    <div class="loading-spinner">
      <div class="spinner"></div>
      <p>Generating images with AI...</p>
      <p class="progress-text">Preparing request...</p>
    </div>
  `;
  
  const statusEl = document.getElementById('template-status');
  if (statusEl) {
    statusEl.innerHTML = '';
    statusEl.appendChild(progressMsg);
    statusEl.style.display = 'block';
  }

  const generateBtn = document.getElementById('generate-images-btn');
  if (generateBtn) {
    generateBtn.disabled = true;
    generateBtn.textContent = 'Generating...';
  }

  try {
    const images = await generateImagePair(prompt, (progress) => {
      const progressText = progressMsg.querySelector('.progress-text');
      if (progressText) {
        progressText.textContent = progress;
      }
    });

    if (images.length === 2) {
      renderGeneratedImages(images);

      // Save to Firestore
      await db.collection('generations').add({
        userId: currentUser.uid,
        templates: selectedTemplates,
        productName: userProductName,
        specifications: selectedSpecs,
        images: images.map(img => ({ 
          provider: img.provider, 
          url: img.url 
        })),
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      });

      UI.showMessage('template-status', '✅ Images generated successfully!', 'success');
    } else {
      UI.showMessage('template-status', `⚠️ Generated ${images.length}/2 images. Please try again.`, 'error');
    }

  } catch (err) {
    console.error('Generation error:', err);
    UI.showMessage('template-status', '❌ Error generating images: ' + err.message, 'error');
  } finally {
    if (generateBtn) {
      generateBtn.disabled = false;
      generateBtn.textContent = 'Generate Images';
    }
  }

  updateGenerationCounter();
}

// Update generateImagePair to accept progress callback
async function generateImagePair(basePrompt, onProgress) {
  const seed = Date.now();
  const images = [];
  let attempts = 0;
  const maxAttempts = 10;

  while (images.length < 2 && attempts < maxAttempts && generationCount < 20) {
    const prompt = images.length === 0 
      ? basePrompt 
      : `${basePrompt} (variation ${images.length + 1})`;

    if (onProgress) {
      onProgress(`Generating image ${images.length + 1}/2 (attempt ${attempts + 1}/${maxAttempts})...`);
    }

    try {
      // Try Pollinations first
      const image = await generateWithPollinations(prompt, seed + attempts);
      
      if (image) {
        images.push(image);
        generationCount++;
        if (onProgress) {
          onProgress(`✓ Image ${images.length}/2 generated successfully!`);
        }
      } else if (images.length === 0) {
        // Fallback to Stability for first image
        if (onProgress) {
          onProgress(`Trying backup provider...`);
        }
        const backupImage = await generateWithStability(prompt, seed + attempts);
        if (backupImage) {
          images.push(backupImage);
          generationCount++;
          if (onProgress) {
            onProgress(`✓ Image ${images.length}/2 generated successfully!`);
          }
        }
      }
    } catch (err) {
      console.error(`Generation attempt ${attempts + 1} failed:`, err);
      if (onProgress) {
        onProgress(`Attempt ${attempts + 1} failed, retrying...`);
      }
    }

    attempts++;
  }

  return images;
}

// Generate with Pollinations AI
async function generateWithPollinations(prompt, seed, retries = 6) {
  try {
    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=768&height=1024&seed=${seed}&nologo=True&model=flux&safe=true`;

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 45000);

    const response = await fetch(url, {
      method: 'GET',
      mode: 'cors',
      cache: 'no-cache',
      signal: controller.signal
    });

    clearTimeout(timeout);

    if (!response.ok) {
      if ((response.status === 502 || response.status === 524) && retries > 0) {
        const delay = 3000 * (7 - retries);
        await new Promise(resolve => setTimeout(resolve, delay));
        return generateWithPollinations(prompt, seed, retries - 1);
      }
      throw new Error(`Pollinations API error: ${response.status}`);
    }

    const blob = await response.blob();
    
    if (blob.size === 0) {
      throw new Error('Empty image blob received');
    }

    return {
      provider: 'Pollinations AI',
      url: URL.createObjectURL(blob)
    };

  } catch (err) {
    console.error('Pollinations generation error:', err);
    return null;
  }
}

// Generate with Stability AI
async function generateWithStability(prompt, seed) {
  try {
    const payload = {
      text_prompts: [{ text: prompt, weight: 1 }],
      cfg_scale: 7,
      height: 1024,
      width: 1024,
      steps: 30,
      seed: seed
    };

    const response = await fetch('https://api.stability.ai/v1/generation/stable-diffusion-xl-1024-v1-0/text-to-image', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Bearer ${config.api.stability}`
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`Stability API error: ${response.status}`);
    }

    const data = await response.json();

    if (data.artifacts && data.artifacts.length > 0) {
      return {
        provider: 'Stability AI',
        url: `data:image/png;base64,${data.artifacts[0].base64}`
      };
    }

    throw new Error('No images returned from Stability AI');

  } catch (err) {
    console.error('Stability generation error:', err);
    return null;
  }
}

// Render generated images
function renderGeneratedImages(images) {
  const pair = document.getElementById('image-pair');
  const feedbackButtons = document.getElementById('feedback-buttons');
  const container = document.getElementById('generated-images');

  if (!pair || !feedbackButtons || !container) {
    console.error('Required elements not found');
    return;
  }

  // Clear previous content
  pair.innerHTML = '';
  feedbackButtons.innerHTML = '';
  
  // Remove hidden class
  container.classList.remove('hidden');
  container.style.display = 'block';

  // Render images
  images.forEach((item, i) => {
    const div = document.createElement('div');
    div.className = 'image-container';
    
    const img = document.createElement('img');
    img.src = item.url;
    img.alt = `Generated image ${i + 1}`;
    img.onload = () => img.classList.add('loaded');

    const label = document.createElement('div');
    label.className = 'provider-label';
    label.textContent = item.provider;

    div.appendChild(img);
    div.appendChild(label);
    pair.appendChild(div);
  });

  // Store images globally for feedback
  window.currentImages = images;

  // Create feedback buttons with better structure
  const btnContainer = document.createElement('div');
  btnContainer.className = 'feedback-btn-container';
  
  // Create individual buttons
  const leftBtn = document.createElement('button');
  leftBtn.className = 'btn btn-primary';
  leftBtn.innerHTML = '⬅️ <span data-i18n="left_better">Left is better</span>';
  leftBtn.onclick = () => handleFeedback(0);
  
  const rightBtn = document.createElement('button');
  rightBtn.className = 'btn btn-primary';
  rightBtn.innerHTML = '<span data-i18n="right_better">Right is better</span> ➡️';
  rightBtn.onclick = () => handleFeedback(1);
  
  const tieBtn = document.createElement('button');
  tieBtn.className = 'btn btn-secondary';
  tieBtn.innerHTML = '🤝 <span data-i18n="tie">It\'s a tie</span>';
  tieBtn.onclick = () => handleFeedback('tie');
  
  const regenBtn = document.createElement('button');
  regenBtn.className = 'btn btn-danger';
  regenBtn.innerHTML = '🔄 <span data-i18n="regenerate">Both bad - Regenerate</span>';
  regenBtn.onclick = () => generateImages();

  const downloadAllBtn = document.createElement('button');
  downloadAllBtn.className = 'btn btn-success';
  downloadAllBtn.innerHTML = '📥 <span data-i18n="download_all">Download All</span>';
  downloadAllBtn.onclick = () => downloadAllImages();
  
  // Append buttons to container
  btnContainer.appendChild(leftBtn);
  btnContainer.appendChild(rightBtn);
  btnContainer.appendChild(tieBtn);
  btnContainer.appendChild(downloadAllBtn);
  btnContainer.appendChild(regenBtn);
  
  feedbackButtons.appendChild(btnContainer);

  // Apply translations if available
  setTimeout(() => {
    if (window.i18n && window.i18n.renderAll) {
      window.i18n.renderAll();
    }
    container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }, 100);
  
  console.log('Images and buttons rendered successfully');
}

// Add downloadAllImages function
async function downloadAllImages() {
  const images = window.currentImages;
  if (!images || images.length === 0) {
    UI.showMessage('template-status', 'No images to download.', 'error');
    return;
  }

  UI.showMessage('template-status', 'Downloading all images...', 'info');

  for (let i = 0; i < images.length; i++) {
    await new Promise(resolve => setTimeout(resolve, i * 500));
    downloadImage(images[i].url, `design-${Date.now()}-${i + 1}.png`);
  }

  UI.showMessage('template-status', `✅ Downloaded ${images.length} images!`, 'success');
}

// Industry Code Creation (Master Only)
let specCount = 0;

function addSpecification() {
  const container = document.getElementById('spec-container');
  if (!container) return;

  const existingSpecs = container.querySelectorAll('.spec-group').length;
  
  if (existingSpecs >= 5) {
    UI.showMessage('create-account-msg', 'Maximum 5 specifications allowed.', 'error');
    return;
  }

  specCount++;
  const specId = specCount;
  const specGroup = document.createElement('div');
  specGroup.className = 'spec-group';
  specGroup.dataset.specId = specId;

  specGroup.innerHTML = `
    <div class="form-group">
      <label for="spec-${specId}-type">Specification ${specId}</label>
      <select id="spec-${specId}-type">
        <option value="">Select type...</option>
        <option value="size">Size</option>
        <option value="colorScheme">Color Scheme</option>
        <option value="style">Style</option>
        <option value="tone">Tone</option>
        <option value="dimensions">Dimensions</option>
        <option value="material">Material</option>
        <option value="finish">Finish</option>
        <option value="other">Other</option>
      </select>
    </div>
    <div class="value-group" id="spec-${specId}-values">
      <div class="form-group">
        <label for="spec-${specId}-value-1">Value 1</label>
        <input id="spec-${specId}-value-1" type="text" required placeholder="Enter value">
      </div>
    </div>
    <button type="button" class="btn btn-secondary" onclick="addValue(${specId})">
      Add Value
    </button>
    <button type="button" class="btn btn-danger" onclick="removeSpecification(${specId})">
      Remove Specification
    </button>
  `;

  container.appendChild(specGroup);
}

function addValue(specId) {
  const valuesContainer = document.getElementById(`spec-${specId}-values`);
  if (!valuesContainer) return;

  const valueCount = valuesContainer.querySelectorAll('.form-group').length;

  if (valueCount >= 5) {
    UI.showMessage('create-account-msg', 'Maximum 5 values per specification.', 'error');
    return;
  }

  const valueId = valueCount + 1;
  const valueGroup = document.createElement('div');
  valueGroup.className = 'form-group';

  valueGroup.innerHTML = `
    <label for="spec-${specId}-value-${valueId}">Value ${valueId}</label>
    <input id="spec-${specId}-value-${valueId}" type="text" required placeholder="Enter value">
  `;

  valuesContainer.appendChild(valueGroup);
}

function removeSpecification(specId) {
  const specGroup = document.querySelector(`.spec-group[data-spec-id="${specId}"]`);
  if (specGroup) {
    specGroup.remove();
  }
}

function collectSpecifications() {
  const specs = {};
  const specGroups = document.querySelectorAll('.spec-group');

  specGroups.forEach(group => {
    const specId = group.dataset.specId;
    const typeSelect = document.getElementById(`spec-${specId}-type`);
    
    if (!typeSelect || !typeSelect.value) return;

    const specType = typeSelect.value;
    const values = [];

    const valueInputs = group.querySelectorAll(`#spec-${specId}-values input`);
    valueInputs.forEach(input => {
      const value = input.value.trim();
      if (value) values.push(value);
    });

    if (values.length > 0) {
      specs[specType] = values;
    }
  });

  return specs;
}

async function createIndustryCode() {
  if (userRole !== 'master') {
    UI.showMessage('create-account-msg', 'Access denied.', 'error');
    return;
  }

  const industryName = document.getElementById('industry-name')?.value.trim();
  const productName = document.getElementById('product-name')?.value.trim();
  const specs = collectSpecifications();

  if (!industryName || industryName.length < 2) {
    UI.showMessage('create-account-msg', 'Please enter a valid industry name.', 'error');
    return;
  }

  if (!productName || productName.length < 2) {
    UI.showMessage('create-account-msg', 'Please enter a valid product name.', 'error');
    return;
  }

  try {
    UI.showMessage('create-account-msg', 'Creating industry code...', 'info');

    // Generate unique code
    let code;
    let exists = true;
    let attempts = 0;

    while (exists && attempts < 10) {
      code = Math.floor(100000 + Math.random() * 900000).toString();
      const doc = await db.collection('industryCodes').doc(code).get();
      exists = doc.exists;
      attempts++;
    }

    if (exists) {
      throw new Error('Failed to generate unique code');
    }

    // Create industry code
    await db.collection('industryCodes').doc(code).set({
      industryName: industryName,
      productName: productName,
      specifications: specs,
      used: false,
      createdAt: firebase.firestore.FieldValue.serverTimestamp(),
      createdBy: currentUser.uid
    });

    // Display code
    document.getElementById('industry-code').textContent = code;
    UI.showElement('generated-code');

    UI.showMessage('create-account-msg', 'Industry code created successfully!', 'success');

  } catch (err) {
    console.error('Create code error:', err);
    UI.showMessage('create-account-msg', 'Error creating code: ' + err.message, 'error');
  }
}

function copyCode() {
  const code = document.getElementById('industry-code')?.textContent;
  if (!code) return;

  navigator.clipboard.writeText(code).then(() => {
    UI.showMessage('create-account-msg', 'Code copied to clipboard!', 'success');
  }).catch(() => {
    UI.showMessage('create-account-msg', 'Failed to copy code.', 'error');
  });
}

// Setup event listeners
function setupEventListeners() {
  // Login form
  document.getElementById('login-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    handleLogin(email, password);
  });

  // Logout
  document.getElementById('logout-btn')?.addEventListener('click', handleLogout);

  // Switch to register
  document.getElementById('switch-to-register')?.addEventListener('click', () => UI.showRegister());

  // Switch to login
  document.getElementById('switch-to-login')?.addEventListener('click', () => UI.showLogin());

  // Send verification code
  document.getElementById('send-code-btn')?.addEventListener('click', sendVerificationCode);

  // Verify code
  document.getElementById('verify-code-btn')?.addEventListener('click', verifyCode);

  // Complete registration
  document.getElementById('register-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    completeRegistration();
  });

  // Back buttons
  document.getElementById('back-to-step1')?.addEventListener('click', () => {
    UI.hideElement('register-step2');
    UI.showElement('register-step1');
  });

  document.getElementById('back-to-step2')?.addEventListener('click', () => {
    UI.hideElement('register-step3');
    UI.showElement('register-step2');
  });

  // Setup form
  document.getElementById('setup-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    handleSetup();
  });

  // Account form
  document.getElementById('edit-account-btn')?.addEventListener('click', showEditAccount);
  document.getElementById('cancel-edit')?.addEventListener('click', cancelEdit);
  document.getElementById('account-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    updateAccount();
  });

  // Generate images
  document.getElementById('generate-images-btn')?.addEventListener('click', generateImages);

  // Industry code form
  document.getElementById('create-account-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    createIndustryCode();
  });

  document.getElementById('add-spec-btn')?.addEventListener('click', addSpecification);
  document.getElementById('copy-code-btn')?.addEventListener('click', copyCode);

  // Keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    // Escape key - close modals/forms
    if (e.key === 'Escape') {
      if (document.getElementById('account-form')?.style.display !== 'none') {
        cancelEdit();
      }
    }

    // Ctrl/Cmd + Enter - Submit forms
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      const activeForm = document.activeElement.closest('form');
      if (activeForm) {
        activeForm.dispatchEvent(new Event('submit'));
      }
    }

    // Arrow keys for image feedback (when images are visible)
    if (window.currentImages && window.currentImages.length === 2) {
      if (e.key === 'ArrowLeft') {
        handleFeedback(0);
      } else if (e.key === 'ArrowRight') {
        handleFeedback(1);
      } else if (e.key === 'ArrowDown') {
        handleFeedback('tie');
      }
    }
  });

  console.log('Event listeners setup complete');
}

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
  console.log('DOM loaded, initializing app...');
  
  initFirebase();
  initEmailJS();
  setupEventListeners();

  // Set initial language
  const savedLang = localStorage.getItem('userLanguage') || 'en';
  if (window.i18n && window.i18n.setLanguage) {
    window.i18n.setLanguage(savedLang);
  }

  console.log('App initialization complete');
});

// Global functions for backward compatibility
window.showLogin = () => UI.showLogin();
window.showRegister = () => UI.showRegister();
window.showPage = showPage;
window.setLang = setLang;
window.UI = UI;
window.downloadImage = downloadImage;
window.handleFeedback = handleFeedback;
window.addSpecification = addSpecification;
window.addValue = addValue;
window.removeSpecification = removeSpecification;
window.copyCode = copyCode;