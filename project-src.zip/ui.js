/**
 * UI Utilities Module
 * Handles all UI manipulation (show/hide, messages, page navigation)
 */

export const UI = {
  /**
   * Show an element by ID
   */
  showElement(id) {
    const el = document.getElementById(id);
    if (el) {
      el.classList.remove('hidden');
      el.style.display = 'block';
    }
  },

  /**
   * Hide an element by ID
   */
  hideElement(id) {
    const el = document.getElementById(id);
    if (el) {
      el.classList.add('hidden');
      el.style.display = 'none';
    }
  },

  /**
   * Show a message in a specific container
   */
  showMessage(id, message, type = 'info') {
    const el = document.getElementById(id);
    if (el) {
      el.innerHTML = message;
      el.className = `message ${type}`;
      el.style.display = 'block';
    }
  },

  /**
   * Hide a message container
   */
  hideMessage(id) {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  },

  /**
   * Navigate to a specific page
   */
  showPage(pageId, userRole = null) {
    const pages = [
      'setup-page', 
      'account-page', 
      'template-page', 
      'records-page', 
      'create-account-page'
    ];

    // Access control for create-account-page
    if (pageId === 'create-account-page' && userRole !== 'master') {
      this.showMessage('template-status', 'Access denied: Only master accounts can create industry codes.', 'error');
      pageId = 'template-page';
    }

    pages.forEach(id => this.hideElement(id));
    this.showElement(pageId);
  },

  /**
   * Show the main application interface
   */
  showMainApp() {
    const authContainer = document.getElementById('auth-container');
    const mainApp = document.getElementById('main-app');
    if (authContainer && mainApp) {
      authContainer.style.display = 'none';
      mainApp.classList.add('show');
    }
  },

  /**
   * Show the authentication interface
   */
  showAuth() {
    const authContainer = document.getElementById('auth-container');
    const mainApp = document.getElementById('main-app');
    if (authContainer && mainApp) {
      authContainer.style.display = 'block';
      mainApp.classList.remove('show');
      this.hideElement('product-warning');
    }
  },

  /**
   * Show login form
   */
  showLogin() {
    this.showElement('login-form');
    this.hideElement('register-form');
    this.showElement('switch-to-register');
    this.hideElement('switch-to-login');
    this.hideMessage('login-msg');
  },

  /**
   * Show registration form
   */
  showRegister() {
    this.hideElement('login-form');
    this.showElement('register-form');
    this.hideElement('switch-to-register');
    this.showElement('switch-to-login');
    this.showElement('register-step1');
    this.hideElement('register-step2');
    this.hideElement('register-step3');
    document.getElementById('register-form')?.reset();
    this.hideMessage('register-msg-step1');
    this.hideMessage('register-msg-step2');
    this.hideMessage('register-msg-step3');
  },

  /**
   * Check and show/hide product warning
   */
  checkProductWarning(productName) {
    const warning = document.getElementById('product-warning');
    if (warning) {
      if (productName && productName.trim().length >= 2) {
        this.hideElement('product-warning');
      } else {
        this.showElement('product-warning');
      }
    }
  },

  /**
   * Toggle master account specific UI elements
   */
  toggleMasterUI(isMaster) {
    if (isMaster) {
      this.showElement('create-account-link');
    } else {
      this.hideElement('create-account-link');
    }
  }
};