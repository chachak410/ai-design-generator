/**
 * Industry Code Management Module
 * Handles creation and management of industry codes (Master only)
 */

import { UI } from '../../utils/ui.js';
import { Validation } from '../../utils/validation.js';
import { Sanitizer } from '../../utils/sanitizer.js';
import { Helpers } from '../../utils/helpers.js';
import { config } from '../../config.js';

export class IndustryCodes {
  constructor(auth, db) {
    this.auth = auth;
    this.db = db;
  }

  /**
   * Create a new industry code
   */
  async createIndustryCode(industryName, productName, specifications) {
    const userRole = this.auth.getUserRole();

    // Only master can create industry codes
    if (userRole !== 'master') {
      UI.showMessage('create-account-msg', 'Access denied. Only master accounts can create industry codes.', 'error');
      return { success: false };
    }

    const sanitizedIndustryName = Sanitizer.sanitizeText(industryName);
    const sanitizedProductName = Sanitizer.sanitizeText(productName);

    // Validate inputs
    const validation = Validation.validateIndustryCodeCreation(
      sanitizedIndustryName,
      sanitizedProductName,
      specifications
    );

    if (!validation.isValid) {
      UI.showMessage('create-account-msg', validation.errors.join(' '), 'error');
      return { success: false };
    }

    try {
      UI.showMessage('create-account-msg', 'Creating industry code...', 'info');

      // Generate unique industry code
      const industryCode = await this.generateUniqueCode();

      // Create industry code document in Firestore
      await this.db.collection('industryCodes').doc(industryCode).set({
        industryName: sanitizedIndustryName,
        productName: sanitizedProductName,
        specifications: specifications,
        used: false,
        createdAt: firebase.firestore.FieldValue.serverTimestamp(),
        createdBy: this.auth.getCurrentUser().uid
      });

      // Display the generated code
      this.displayGeneratedCode(industryCode);

      UI.showMessage('create-account-msg', 'Industry code created successfully!', 'success');

      return { success: true, code: industryCode };

    } catch (err) {
      console.error('Error creating industry code:', err);
      UI.showMessage('create-account-msg', 'Error creating industry code: ' + err.message, 'error');
      return { success: false, error: err.message };
    }
  }

  /**
   * Generate a unique industry code
   */
  async generateUniqueCode() {
    let code;
    let exists = true;
    let attempts = 0;
    const maxAttempts = 10;

    while (exists && attempts < maxAttempts) {
      code = Helpers.generateIndustryCode();
      
      // Check if code already exists
      const doc = await this.db.collection('industryCodes').doc(code).get();
      exists = doc.exists;
      
      attempts++;
    }

    if (exists) {
      throw new Error('Failed to generate unique code after multiple attempts');
    }

    return code;
  }

  /**
   * Display generated industry code
   */
  displayGeneratedCode(code) {
    const codeDisplay = document.getElementById('industry-code');
    const codeContainer = document.getElementById('generated-code');

    if (codeDisplay) {
      codeDisplay.textContent = code;
    }

    if (codeContainer) {
      UI.showElement('generated-code');
    }
  }

  /**
   * Copy industry code to clipboard
   */
  async copyCode() {
    const codeDisplay = document.getElementById('industry-code');
    
    if (!codeDisplay) return;

    const code = codeDisplay.textContent;
    const result = await Helpers.copyToClipboard(code);

    if (result.success) {
      UI.showMessage('create-account-msg', 'Industry code copied to clipboard!', 'success');
    } else {
      UI.showMessage('create-account-msg', 'Failed to copy code.', 'error');
    }
  }

  /**
   * Add specification to the form
   */
  addSpecification() {
    const container = document.getElementById('spec-container');
    if (!container) return;

    const specCount = container.querySelectorAll('.spec-group').length;
    
    if (specCount >= config.app.maxSpecifications) {
      UI.showMessage('create-account-msg', `Maximum ${config.app.maxSpecifications} specifications allowed.`, 'error');
      return;
    }

    const specId = specCount + 1;
    const specGroup = document.createElement('div');
    specGroup.className = 'spec-group';
    specGroup.dataset.specId = specId;

    specGroup.innerHTML = `
      <div class="form-group">
        <label for="spec-${specId}-type">Specification ${specId}</label>
        <select id="spec-${specId}-type">
          <option value="">Select type...</option>
          <option value="size">Size</option>
          <option value="colorScheme">Color Scheme</option>
          <option value="style">Style</option>
          <option value="tone">Tone</option>
          <option value="dimensions">Dimensions</option>
          <option value="material">Material</option>
          <option value="finish">Finish</option>
          <option value="other">Other</option>
        </select>
      </div>
      <div class="value-group" id="spec-${specId}-values">
        <div class="form-group">
          <label for="spec-${specId}-value-1">Value 1</label>
          <input id="spec-${specId}-value-1" type="text" required placeholder="Enter value">
        </div>
      </div>
      <button type="button" class="btn btn-secondary btn-add-value" data-spec-id="${specId}">
        Add Value
      </button>
      <button type="button" class="btn btn-danger btn-remove-spec" data-spec-id="${specId}">
        Remove Specification
      </button>
    `;

    container.appendChild(specGroup);

    // Add event listeners
    this.setupSpecificationListeners(specId);
  }

  /**
   * Add value to a specification
   */
  addValue(specId) {
    const valuesContainer = document.getElementById(`spec-${specId}-values`);
    if (!valuesContainer) return;

    const valueCount = valuesContainer.querySelectorAll('.form-group').length;

    if (valueCount >= config.app.maxSpecValues) {
      UI.showMessage('create-account-msg', `Maximum ${config.app.maxSpecValues} values per specification.`, 'error');
      return;
    }

    const valueId = valueCount + 1;
    const valueGroup = document.createElement('div');
    valueGroup.className = 'form-group';

    valueGroup.innerHTML = `
      <label for="spec-${specId}-value-${valueId}">Value ${valueId}</label>
      <input id="spec-${specId}-value-${valueId}" type="text" required placeholder="Enter value">
    `;

    valuesContainer.appendChild(valueGroup);
  }

  /**
   * Remove a specification
   */
  removeSpecification(specId) {
    const specGroup = document.querySelector(`.spec-group[data-spec-id="${specId}"]`);
    if (specGroup) {
      specGroup.remove();
    }
  }

  /**
   * Setup event listeners for specification controls
   */
  setupSpecificationListeners(specId) {
    // Add value button
    const addValueBtn = document.querySelector(`.btn-add-value[data-spec-id="${specId}"]`);
    if (addValueBtn) {
      addValueBtn.addEventListener('click', () => this.addValue(specId));
    }

    // Remove specification button
    const removeSpecBtn = document.querySelector(`.btn-remove-spec[data-spec-id="${specId}"]`);
    if (removeSpecBtn) {
      removeSpecBtn.addEventListener('click', () => this.removeSpecification(specId));
    }
  }

  /**
   * Collect specifications from the form
   */
  collectSpecifications() {
    const specs = {};
    const specGroups = document.querySelectorAll('.spec-group');

    specGroups.forEach(group => {
      const specId = group.dataset.specId;
      const typeSelect = document.getElementById(`spec-${specId}-type`);
      
      if (!typeSelect || !typeSelect.value) return;

      const specType = typeSelect.value;
      const values = [];

      const valueInputs = group.querySelectorAll(`#spec-${specId}-values input`);
      valueInputs.forEach(input => {
        const value = input.value.trim();
        if (value) values.push(value);
      });

      if (values.length > 0) {
        specs[specType] = values;
      }
    });

    return specs;
  }

  /**
   * Get list of all industry codes (master only)
   */
  async getAllIndustryCodes() {
    const userRole = this.auth.getUserRole();

    if (userRole !== 'master') {
      return { success: false, error: 'Access denied' };
    }

    try {
      const snapshot = await this.db.collection('industryCodes')
        .orderBy('createdAt', 'desc')
        .get();

      const codes = snapshot.docs.map(doc => ({
        code: doc.id,
        ...doc.data()
      }));

      return { success: true, codes };

    } catch (err) {
      console.error('Error getting industry codes:', err);
      return { success: false, error: err.message };
    }
  }
}