/**
 * Setup Module
 * Handles initial user setup (first-time login)
 */

import { UI } from '../../utils/ui.js';
import { Validation } from '../../utils/validation.js';
import { Sanitizer } from '../../utils/sanitizer.js';
import { FirebaseHelper } from '../../utils/firebase.js';

export class Setup {
  constructor(auth, db) {
    this.auth = auth;
    this.db = db;
  }

  /**
   * Handle setup form submission
   */
  async handleSetup(name, productName) {
    const currentUser = this.auth.getCurrentUser();
    
    if (!currentUser) {
      UI.showMessage('setup-msg', 'Please sign in to complete setup.', 'error');
      return { success: false };
    }

    const sanitizedName = Sanitizer.sanitizeText(name);
    const sanitizedProductName = Sanitizer.sanitizeText(productName);

    // Validate inputs
    const validation = Validation.validateProfile(sanitizedName, sanitizedProductName);
    if (!validation.isValid) {
      UI.showMessage('setup-msg', validation.errors.join(' '), 'error');
      return { success: false };
    }

    try {
      UI.showMessage('setup-msg', 'Saving profile...', 'info');

      // Get existing user data
      const userData = await FirebaseHelper.getUserData(this.db, currentUser.uid);

      // Update user document
      await FirebaseHelper.updateUserData(this.db, currentUser.uid, {
        name: sanitizedName,
        productName: sanitizedProductName,
        setupCompleted: true
      });

      // Update Firebase Auth display name
      await currentUser.updateProfile({ displayName: sanitizedName });

      // Update auth instance
      this.auth.setUserProductName(sanitizedProductName);

      UI.showMessage('setup-msg', 'Profile saved successfully!', 'success');

      // Navigate to template page after short delay
      setTimeout(() => {
        UI.showPage('template-page', this.auth.getUserRole());
      }, 1000);

      return { success: true };

    } catch (err) {
      UI.showMessage('setup-msg', 'Error saving profile: ' + err.message, 'error');
      return { success: false, error: err.message };
    }
  }

  /**
   * Check if user needs setup
   */
  needsSetup() {
    const currentUser = this.auth.getCurrentUser();
    const productName = this.auth.getUserProductName();

    return currentUser && 
           (!currentUser.displayName || 
            !productName || 
            productName.trim().length < 2);
  }
}